# phonebook2.py
__author__ = 'Riju'
__email__ = 'rijumone@live.com'

import os
import re
import csv
import time
import pickle
# from pprint import pprint
from loguru import logger
logger.add("log.log", compression="zip", rotation="10 MB")

class PhonebookEntry:
	'''class to emulate phonebook entry'''
	state = None
	last_name = None
	first_name = None
	phone_number = None

	def __init__(self, first_name, last_name, state, phone_number):
		self.state = state
		self.last_name = last_name
		self.first_name = first_name
		self.phone_number = self._transform_phone_number(phone_number)

	def __repr__(self):
		return '<PhonebookEntry({}, {}, {}, {}>'.format(
			self.first_name, 
			self.last_name, 
			self.state, 
			self.phone_number,
			)

	def _transform_phone_number(self, phone_number):
		''' return phone number as string
		in the format: (917) 958-1191 '''
		phone_number = phone_number.replace('(', '').replace(')', '').replace('-', '').replace(' ', '')
		_tmp = '(' + phone_number[:3] + ') ' + phone_number[3:6] + '-' + phone_number[6:]
		return _tmp
		


class Phonebook:
	phonebook = None
	phone_number_pattern = '^(\+0?1\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$'

	def __init__(self):
		self.phonebook = {}

	def insert(self, row):
		# attempt to identify row's format
		key = None
		state = None
		last_name = None
		first_name = None
		phone_number = None

		
		if len(row) < 3 or len(row) > 4:
			return
		

		try:
			if len(row) == 3:
				# if there are only 3 items in the line, it is of format: Firstname Lastname, 9179581191, New York
				key = row[0].split(' ')[1].lower()
				first_name = row[0].split(' ')[0].strip()
				last_name = row[0].split(' ')[1].strip()
				phone_number = row[1].strip()
				state = row[2].strip()
			elif re.match(self.phone_number_pattern, row[2].strip()):
				# if third value matches phone number
				key = row[1].strip().lower()
				first_name = row[0].strip()
				last_name = row[1].strip()
				phone_number = row[2].strip()
				state = row[3].strip()
			elif re.match(self.phone_number_pattern, row[3].strip()):
				# if fourth value matches phone number
				key = row[0].strip().lower()
				first_name = row[1].strip()
				last_name = row[0].strip()
				phone_number = row[3].strip()
				state = row[2].strip()
		except Exception as e:
			logger.error('unable to parse row')
			logger.debug('raw row: {}'.format(str(row)))

		if key is not None:
			if key not in self.phonebook:
				self.phonebook[key] = []
			self.phonebook[key].append(PhonebookEntry(first_name, last_name, state, phone_number))

	def search(self, search_key):
		search_key_l = search_key.lower()
		return self.phonebook[search_key_l] if search_key_l in self.phonebook else None

	def __repr__(self):
		return '<Phonebook(phonebook={})>'.format(self.phonebook)

def search_and_print(cleaned_line, pb_obj):
	search_results = pb_obj.search(cleaned_line)
	print('Matches for {}'.format(cleaned_line))
	if search_results is None:
		print('No results found')
	else:
		ctr = 0
		for result in search_results:
			ctr += 1
			print('Result {ctr}: {last_name}, {first_name}, {state}, {phone}'.format(
				ctr=ctr,
				last_name=result.last_name,
				first_name=result.first_name,
				state=result.state,
				phone=result.phone_number,
				))

def main():
	
	

	if os.path.isfile('pb_obj.pickle') and os.path.getmtime('phone_dataset.csv') <= os.path.getmtime('pb_obj.pickle'):
		# pickle can be used
		with open('pb_obj.pickle', 'rb') as pickle_file_obj:
			pb_obj = pickle.load(pickle_file_obj)
	else:
		with open('phone_dataset.csv') as in_file:
			pb_obj = Phonebook()
			reader = csv.reader(in_file)
			for row in reader:
				pb_obj.insert(row)

		# write pickle to file here
		with open('pb_obj.pickle', 'wb') as pickle_file_obj:
			pickle.dump(pb_obj, pickle_file_obj) 

	with open('query.txt') as query_file:
		for line in query_file.readlines():
			search_and_print(line.strip(), pb_obj)

			

if __name__ == '__main__':
	main()
	















